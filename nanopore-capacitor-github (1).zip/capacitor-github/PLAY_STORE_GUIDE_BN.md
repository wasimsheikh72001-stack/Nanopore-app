# Play Store-এ দেওয়ার গাইড (Nanopore Analyzer)

> সতর্কতা: Play Console-এর নিয়ম ও ফর্ম বদলায়। নিচের তথ্যের যেগুলো আমি যাচাই করেছি (লক্ষ্য API 36, ১২ জন টেস্টার ১৪ দিন) সেগুলো ছাড়া বাকিগুলো পরামর্শ; জমা দেওয়ার আগে Play Console-এর বর্তমান নির্দেশ মিলিয়ে নিন।

## ধাপ ১ — সই-চাবি একবার বানান
১. repository → Settings → Secrets and variables → Actions → New repository secret:
   - `KEYSTORE_PASSWORD` = আপনার বাছা শক্ত পাসওয়ার্ড (কোথাও লিখে রাখুন)
   - `KEY_ALIAS` = `upload`
২. Actions → **Make signing key (run ONCE)** → Run workflow।
৩. রান শেষে Artifacts থেকে `signing-key-KEEP-SECRET` নামান। ভেতরে `upload.jks` (চাবির ফাইল, **নিরাপদ জায়গায় ব্যাকআপ রাখুন**, কাউকে দেবেন না) ও `keystore.base64.txt`।
৪. `keystore.base64.txt`-এর পুরো লেখা কপি করে নতুন secret `KEYSTORE_BASE64`-এ বসান।
৫. ওই রান মুছে দিন (Artifacts এক দিন পরে নিজেই মুছে যায়)। এই workflow আর চালাবেন না, চালালে নতুন চাবি হবে।

## ধাপ ২ — AAB বানান
Actions → **Build signed AAB (Play Store)** → Run workflow (version name দিন, যেমন 1.0.0) → শেষে Artifacts থেকে `nanopore-analyzer-aab` নামান। প্রতিটি রানে versionCode নিজে বাড়ে, তাই পরের আপডেটও একই ভাবে হবে।

লক্ষ্য API: Google এখন নতুন অ্যাপে Android 16 (API 36) লক্ষ্য চায় (৩১ আগস্ট ২০২৬ থেকে)। প্যাকেজ Capacitor 8 ব্যবহার করে, যা API 36 লক্ষ্য করে (Node 22 ও Java 21 দিয়ে)। কোনো ধাপ ব্যর্থ হলে ত্রুটির লেখাটা পাঠান।

## ধাপ ৩ — প্রাইভেসি পলিসির লিংক
`privacy.html` ফাইলে `[YOUR EMAIL ADDRESS]` দুই জায়গায় আপনার ইমেইল বসান। repository → Settings → Pages → Branch: main, folder: root (/) → Save। লিংক হবে `https://ইউজারনেম.github.io/রিপো/privacy.html` (বা `/www/privacy.html`; যেটা খোলে সেটাই দিন)। এই লিংক Play Console-এ বসবে।

## ধাপ ৪ — Play Console
১. play.google.com/console-এ ডেভেলপার অ্যাকাউন্ট (ফি ও পরিচয় যাচাই আছে; বর্তমান ফি Console-এ দেখুন)।
২. নতুন অ্যাপ → নাম: Nanopore Analyzer, ভাষা English, অ্যাপ (গেম নয়), বিনামূল্যে।
৩. **নতুন ব্যক্তিগত অ্যাকাউন্টের নিয়ম:** প্রোডাকশনে যাওয়ার আগে ক্লোজড টেস্টে অন্তত ১২ জন টেস্টার ১৪ দিন টানা যুক্ত থাকতে হয়, তারপর প্রোডাকশনের আবেদন। বন্ধু/সহপাঠীদের Gmail দিয়ে টেস্টার তালিকা বানান।
৪. AAB আপলোড (প্রথমে ক্লোজড টেস্ট ট্র্যাকে), Play App Signing চালু রাখুন।
৫. Store listing (নিচের লেখা), আইকন ৫১২×৫১২ (`assets/icon-only.png` ছোট করে), ফিচার গ্রাফিক ১০২৪×৫০০, ফোনের স্ক্রিনশট কমপক্ষে ২টি।
৬. App content: প্রাইভেসি পলিসি লিংক, Ads = না, Data safety, Content rating, লক্ষ্য দর্শক = প্রাপ্তবয়স্ক (শিশুদের জন্য নয়)।

## Store listing (English, কপি করে বসান)
**App name:** Nanopore Analyzer
**Short description (75/80):** Nanopore current-trace analysis: baseline, blockade, dwell time and figures
**Full description (1554/4000):**

Nanopore Analyzer turns raw nanopore simulation data into finished results in a few taps.

WHAT IT DOES
• Open data files (DOCX, PDF, CSV, TXT, spreadsheets) or paste numbers: time and ionic current.
• Detects the open-pore baseline, minimum current, translocation start/end and dwell time automatically, and draws the annotated trace with ΔI and Δt marked.
• Correct any value by hand and the graph and results update at once.
• Batch mode: load 10–15+ simulation files, see every trace, and an all-traces overlay with scaling options.
• Final-analysis table per file: radius, length, DNA base pairs, voltage, simulated and theoretical baseline current (cylindrical, conical or custom model), ΔI, ΔI/I0 and dwell time, with plots against any parameter.
• Paper tab: compare your trace with a graph from a paper (image, screenshot, PDF or Word file). The app finds the axes, reads the curve, overlays both on one graph and writes a comparison table (baseline, minimum, blockade, contrast, dwell time, error %) with a discussion.
• Publication-style figures: multi-panel graphs with title, panel labels and captions, exported as PNG, JPG, PDF or Word at print resolution.
• Optional AI help (bring your own key for Gemini, ChatGPT, Grok or Claude) to discuss results against the literature.
• English and Bangla interface, light and dark themes.

PRIVACY
Your files are processed on your device. No account, no ads, no tracking. AI features are optional and use your own key.

Built by Wasim Sheikh (B.Sc. EEE, DUET) for nanopore researchers and students.

## Data safety ফর্মের উত্তরের খসড়া
অ্যাপের আচরণ: কোনো অ্যাকাউন্ট নেই, বিজ্ঞাপন নেই, বিশ্লেষণ/ট্র্যাকিং নেই, ডেভেলপারের কোনো সার্ভার নেই। সবকিছু ডিভাইসে থাকে।
- Does your app collect or share any of the required user data types? → আমার বোঝায় **ডেভেলপার কিছু সংগ্রহ করে না**, তাই "No data collected" বেছে নেওয়া যায়।
- ঐচ্ছিক AI সুবিধায় ব্যবহারকারীর নিজের কী দিয়ে লেখা/ছবি তাঁর বেছে নেওয়া প্রোভাইডারে যায়। Google-এর সংজ্ঞায় এটা "ব্যবহারকারীর নির্দেশে তৃতীয় পক্ষে পাঠানো" ধরা হবে কি না ফর্মের ব্যাখ্যা পড়ে আপনি নিজে সিদ্ধান্ত নিন। দ্বিধা থাকলে "Data shared" অংশে "App activity / Other user-generated content, শুধু ব্যবহারকারীর অনুরোধে, ঐচ্ছিক" বেছে প্রাইভেসি পলিসির সাথে মিল রাখুন।
- Data encrypted in transit → হ্যাঁ (প্রোভাইডারের HTTPS)।
- Data deletion → অ্যাকাউন্ট নেই; অ্যাপের ডেটা মুছলে সব মুছে যায়।

## Content rating
প্রশ্নমালায় সহিংসতা, যৌনতা, জুয়া, ব্যবহারকারী-থেকে-ব্যবহারকারী যোগাযোগ কিছুই নেই; ফল সম্ভবত "সবার জন্য"। শেষ ফলাফল Console দেখাবে।

## লগইন/মনিটরিং পরে যোগ করলে
প্রাইভেসি পলিসি, Data safety ও (অ্যাকাউন্ট খোলা গেলে) অ্যাকাউন্ট মোছার ব্যবস্থা আপডেট করতে হবে।
