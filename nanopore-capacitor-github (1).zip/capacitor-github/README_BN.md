# Nanopore Analyzer — GitHub দিয়ে Android APK

## কীভাবে APK বানাবেন (কম্পিউটার ছাড়া, ফোনের ব্রাউজার থেকেও হয়)
১. github.com-এ নতুন একটি repository খুলুন (যেমন nanopore-app)।
২. এই zip-এর ভেতরের সব ফাইল ও ফোল্ডার (`www`, `.github`, `package.json`, `capacitor.config.json`, `.gitignore`) repository-তে আপলোড করুন।
   (`.github` ফোল্ডারটি লুকানো থাকতে পারে; ফোনে না পেলে কম্পিউটার থেকে "Upload files" দিয়ে দিন।)
৩. repository → **Actions** ট্যাব → **Build Android APK (test)** → **Run workflow**।
৪. ৫–১০ মিনিট পরে রান শেষ হলে ওই রানের পাতার নিচে **Artifacts** থেকে `nanopore-analyzer-apk` নামান, zip খুলে `app-debug.apk` ফোনে ইনস্টল করুন।

## আগের সমস্যা: ডাউনলোড লিংক আসত, কিন্তু ফাইল নামত না — কেন?
Capacitor অ্যাপ আসলে একটি WebView (অ্যাপের ভেতরের ছোট ব্রাউজার)। সাধারণ Chrome-এ `<a download>` বা blob লিংকে ক্লিক করলে ব্রাউজারের "ডাউনলোড ম্যানেজার" ফাইল সেভ করে। কিন্তু Capacitor-এর WebView-তে ওই ডাউনলোড ম্যানেজার চালু থাকে না, তাই লিংক দেখা গেলেও কিছু সেভ হয় না। HTML ফাইল সরাসরি Chrome-এ খুললে ডাউনলোড ম্যানেজার আছে বলে ঠিকই নামে।

## সমাধান (এই প্যাকেজে করা আছে)
- অ্যাপের কোডে এখন Capacitor চেনা যায়: ফাইল তৈরি হলে `@capacitor/filesystem` দিয়ে ফোনের ক্যাশে লেখা হয়, তারপর `@capacitor/share` দিয়ে "শেয়ার/সেভ" মেনু খোলে (সেখান থেকে Files-এ সেভ, Drive, WhatsApp ইত্যাদি বাছুন)।
- দুটি প্লাগিন `package.json`-এ দেওয়া আছে, workflow নিজেই ইনস্টল ও sync করে — আপনাকে কিছু করতে হবে না।
- সাধারণ ব্রাউজারে বা HTML ফাইলে আগের মতোই সরাসরি ডাউনলোড হয়।

## নিজের কম্পিউটারে বানাতে চাইলে
```
npm install
npx cap add android
npx cap sync android
npx cap open android      # Android Studio খুলবে → Build → Build APK
```
`www` ফোল্ডারের ফাইল বদলালে আবার `npx cap sync android` দিন।


## Play Store-এর জন্য
`PLAY_STORE_GUIDE_BN.md` দেখুন (সই-চাবি, signed AAB, প্রাইভেসি পলিসি, লিস্টিং লেখা)।
